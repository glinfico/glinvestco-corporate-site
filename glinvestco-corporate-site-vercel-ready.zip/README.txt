GLINVESTCO LP corporate website. Static HTML/CSS/JS.
Production domain: https://glinvestco.com
Preserves the approved logo, design, styles and imagery.
Deploy the contents of this folder as the project root.
